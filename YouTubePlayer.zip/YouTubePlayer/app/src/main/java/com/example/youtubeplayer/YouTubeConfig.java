package com.example.youtubeplayer;

public class YouTubeConfig
{
    public  YouTubeConfig()
    {

    }

    private static final String API_KEY = "AIzaSyDPNiBWd5XAYcRun67HNql7SDLlXmCDuM4";

    public static String getApiKey() {
        return API_KEY;
    }
}
